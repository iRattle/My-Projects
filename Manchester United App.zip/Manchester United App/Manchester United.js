

document.addEventListener('DOMContentLoaded', () => {

  // ── Search Bar Toggle ──────────────────────────────────────────
  const searchToggle = document.getElementById('searchToggle');
  const searchBar    = document.getElementById('searchBar');

  if (searchToggle && searchBar) {
    searchToggle.addEventListener('click', () => {
      const isHidden = searchBar.classList.contains('hidden');
      searchBar.classList.toggle('hidden', !isHidden);
      if (isHidden) {
        searchBar.querySelector('input')?.focus();
      }
    });

    // Close search on Escape
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') searchBar.classList.add('hidden');
    });
  }


  // ── Mobile Menu ────────────────────────────────────────────────
  const menuToggle = document.getElementById('menuToggle');
  const menuClose  = document.getElementById('menuClose');
  const mobileMenu = document.getElementById('mobileMenu');

  function openMenu() {
    mobileMenu?.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeMenu() {
    mobileMenu?.classList.remove('open');
    document.body.style.overflow = '';
  }

  menuToggle?.addEventListener('click', openMenu);
  menuClose?.addEventListener('click', closeMenu);

  // Close if clicking outside the panel
  mobileMenu?.addEventListener('click', (e) => {
    if (e.target === mobileMenu) closeMenu();
  });



  // ── Sticky Nav shadow on scroll ────────────────────────────────
  const nav = document.querySelector('nav');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 10) {
      nav?.classList.add('shadow-red-900/20');
    } else {
      nav?.classList.remove('shadow-red-900/20');
    }
  });


  // ── Smooth scroll for anchor links ────────────────────────────
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (e) => {
      const target = document.querySelector(anchor.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });


  // ── Lazy fade-in on scroll ─────────────────────────────────────
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity    = '1';
        entry.target.style.transform  = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.card-hover').forEach(card => {
    card.style.opacity   = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = 'opacity 0.5s ease, transform 0.5s ease, box-shadow 0.25s ease';
    observer.observe(card);
  });

});


// ── Men's First Team Carousel ──────────────────────────────────
(function initMensCarousel() {
  const track   = document.getElementById('mensCarouselTrack');
  const prevBtn = document.getElementById('mensCarouselPrev');
  const nextBtn = document.getElementById('mensCarouselNext');
  const dots    = document.querySelectorAll('.mens-dot');

  if (!track) return;

  const cards = track.children;
  let current = 0;

  function getVisibleCount() {
    if (window.innerWidth < 768) return 2;
    if (window.innerWidth < 1024) return 3;
    return 5;
  }

  function getCardWidth() {
    return cards[0]?.getBoundingClientRect().width + 16; // 16 = gap-4
  }

  function totalPages() {
    return Math.max(1, cards.length - getVisibleCount() + 1);
  }

  function updateDots() {
    dots.forEach((dot, i) => {
      const active = i === current;
      dot.classList.toggle('bg-red-600',  active);
      dot.classList.toggle('w-5',         active);
      dot.classList.toggle('bg-gray-600', !active);
      dot.classList.toggle('w-2',         !active);
    });
  }

  function goTo(idx) {
    const pages = totalPages();
    current = Math.max(0, Math.min(idx, pages - 1));
    const offset = current * getCardWidth();
    track.style.transform = `translateX(-${offset}px)`;
    prevBtn.disabled = current === 0;
    nextBtn.disabled = current >= pages - 1;
    prevBtn.classList.toggle('opacity-30', current === 0);
    nextBtn.classList.toggle('opacity-30', current >= pages - 1);
    updateDots();
  }

  prevBtn?.addEventListener('click', () => goTo(current - 1));
  nextBtn?.addEventListener('click', () => goTo(current + 1));

  dots.forEach((dot, i) => dot.addEventListener('click', () => goTo(i)));

  // Touch / swipe support
  let touchStartX = 0;
  track.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
  track.addEventListener('touchend',   e => {
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 40) goTo(diff > 0 ? current + 1 : current - 1);
  });

  // Reset on resize
  window.addEventListener('resize', () => goTo(0));

  goTo(0);
})();



// ── FAQ Accordion ──────────────────────────────────────────────
function toggleFaq(btn) {
  const item = btn.closest('.faq-item');
  const body = item.querySelector('.faq-body');
  const icon = item.querySelector('.faq-icon');
  const isOpen = body.style.maxHeight && body.style.maxHeight !== '0px';

  // Close all others
  document.querySelectorAll('.faq-item').forEach(el => {
    el.querySelector('.faq-body').style.maxHeight = '0px';
    el.querySelector('.faq-icon').style.transform = 'rotate(0deg)';
    el.classList.remove('border-red-800');
    el.classList.add('border-gray-800');
  });

  // Toggle clicked
  if (!isOpen) {
    body.style.maxHeight = body.scrollHeight + 'px';
    icon.style.transform = 'rotate(180deg)';
    item.classList.add('border-red-800');
    item.classList.remove('border-gray-800');
  }
}




