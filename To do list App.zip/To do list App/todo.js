 let add=()=>{
    let input = document.getElementById('feeder')
    let bucket = document.getElementById('add')
    let struc = document.createElement('div')
    struc.innerHTML = input.value
    struc.className='bg-white/10 text-white px-4 py-2 rounded-xl mt-2';
    bucket.appendChild(struc)
    input.value=''
}