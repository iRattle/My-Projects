// practice 1
console.log('Hello World')

//practice 2
console.log("Welcome to JavaScript")

//practice 3
let x = 10;
let y = 20;
console.log(x + y)

//practice 4
let name = 'Tioluwani';
console.log(name)

//practice 5

/* let Bolu = 'Boy';
const Daniel = 'Boy'

let Bolu = 'Girl'
const Daniel = 'Girl'*/

// Answer
//console.log(Bolu)
//console.log(Daniel)
// it gives an error i cant asign a variable twice


//practice 6
const a = 5;
const b = 10;

let sum = a + b;

console.log(sum)

//practice 7
{
let x = 10;
let y = 5;
console.log(x * y);
}

//practice 8

const dog = 15;
const cat = 4;

let pig = (15 % 4)

console.log(pig)


//practice 9

console.log(5 == "5");
console.log(5 === "5");

//practice 10

if (dog>14){
    console.log('Adult')
}

if (dog % 2===0){
    console.log(dog +  'is even')
} else
    {console.log(dog +  'is odd')}

//practice 11



const studentScore = { sade: 54, bimpe: 88, marylyn: 95, fola: 77 };

let nickName = "sade"; 

if (studentScore[nickName] >= 50) {
    console.log("Pass");
} else {
    console.log("Fail");
}


const dogAge = {bingo:10, billy:4, cyrus:3, barbie:12}

let ageDictector = '';

for (let age in dogAge ){
if (dogAge[age] >=9){
    ageDictector += age+ "Young Dog" + "<br>"
}
else{
    ageDictector += age+ "Old Dog" + "<br>"
}

}

console.log(ageDictector)


for (let t=1; t<=10; t++){
    console.log(t);
}

let c = 1;

while (c <= 10) {

    console.log(c);
    c++;

}



let fruits = ["Apple", "Banana", "Mango"];

for(let f=0; f < fruits.length; f++){
    console.log(fruits[f])
}


let alphabet = "JavaScript is fun";

console.log(alphabet.length);

let word = "hello";

console.log(word.toUpperCase());

let rattlelikes = "JavaScript";

console.log(rattlelikes.slice(4, 10));

let ujj="100"
console.log(Number(ujj));

let num = 3.4567;
console.log(num.toFixed(2));

console.log(Math.sqrt(64));



function checkNumber(num) {
    if (num > 0) {
        console.log("Positive");
    } else if (num < 0) {
        console.log("Negative");
    } else {
        console.log("Zero");
    }
}

const person = {
    name: "Sade",
    age: 20,
    city: "Lagos"
};

console.log(person.name);

person.country = "Nigeria";
console.log(person);

function myFunction() {
    let message = "I am inside a function";
}




let globalMessage = "I am global";

function myFunction() {
    console.log(globalMessage); 
}
myFunction();

alert("I am a big nigga")



let dome = `Tioluwani is from ${city}`;
console.log(dome)

let city = "Akute"

