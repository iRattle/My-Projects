let userData = {name:'Tolu', age:21, eyecolour: 'brown eye' };

let bimbo = ['sade', 'bisi', 'salewa'];

let comp = `My Name is ${userData.name} he is ${userData.age} he has a ${userData.eyecolour}`;

console.log(comp.toUpperCase());

console.log(comp.length);



let email = 'tioluwanidanielajose@gmail.com';

let realEmail = email.includes('@');

console.log(realEmail);


let birth = '2004';

birth = Number(birth)

console.log(birth+1)

console.log(birth>5)

let tunde = `i left a boy called ${userData.name}`;

console.log(tunde)



//loop

for (let t=0; t<7; t++){
    console.log('in Loop', t)
}

console.log("loop end")

const dogs = ["billy", "forza","braca", "lite", "rife", "rattle"]

for (let r=0; r<dogs.length; r++){
    console.log(dogs[r]);
}

let u =0;

while(u<9){
    console.log('in loop', u);
    u++;
    
}

let f =0;

while (f<dogs.length){
    console.log(dogs[f])
    f++
}

if(userData.age<30){
    console.log('Get your monry up lad reg "3:21am"')
}

if (bimbo.length>2){
    console.log("There's really a lot bitches here")
}

const password = 'tolsznjoznigiugyuf@'

if (password.length>=9&& password.includes('@')){
    console.log('Dear User Your Password is Strong...')
}else if(password.length>=15 || password.includes('@')){
    console.log('Dear User Your Password is Good Enough...')
}else{
    console.log("your password is a hackers dream lol")
}

function greet (){
    console.log('Hello There')
}

greet();

const speak = function(){
    console.log('Hello There')
};

speak();



const areaCalc = function(radius){
    return 3.14*radius**2;
}

const area = areaCalc(5)

console.log(area)


for (let h =0; h < 5; h++){
    console.log(h)
}

let q = 0;

while(q<5){
    console.log(q)
    q++
}

